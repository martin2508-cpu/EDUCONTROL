# EDUCONTROL

Sistema de gestión académica de escritorio desarrollado en Python con programación orientada a objetos.

## Funcionalidades

- Registro, edición, búsqueda indirecta por identificación y eliminación de estudiantes.
- Administración de profesores.
- Administración de asignaturas y asignación de docentes.
- Registro y actualización de tres calificaciones por estudiante y asignatura.
- Cálculo automático del promedio y estado (aprobado/reprobado).
- Dashboard con indicadores y gráficas interactivas (donas, barras, línea y ranking): al pasar el cursor
  aparece un tooltip y el sector/barra se resalta; con clic en una barra se abre la asignatura.
- Asignaturas con su propio espacio: cada una tiene su tarjeta (docente, estudiantes, promedio, aprobación)
  y una página de detalle con indicadores, gráficas, ficha del docente y tabla de notas.
- Buscador en estudiantes, profesores, calificaciones y asignaturas; avisos flotantes en lugar de ventanas
  de confirmación; los formularios conservan lo escrito si hay un error.
- Reportes: ranking de estudiantes y resumen por asignatura.

## Tecnologías

- Python 3.10 o superior.
- CustomTkinter para la interfaz.
- Matplotlib (embebido con `FigureCanvasTkAgg`) para las gráficas interactivas.
- Tkinter/ttk para las tablas.
- unittest para pruebas.

## Instalación

1. Instala Python 3.10 o superior.
2. Abre esta carpeta en Visual Studio Code.
3. Crea un entorno virtual:

   ```bash
   python -m venv .venv
   ```

4. Actívalo en Windows:

   ```bash
   .venv\Scripts\activate
   ```

5. Instala las dependencias:

   ```bash
   pip install -r requirements.txt
   ```

## Ejecución

```bash
python main.py
```

## Pruebas

Desde la carpeta principal:

```bash
python -m unittest discover -s pruebas -v
```

## Estructura del proyecto

```text
EDUCONTROL/
├── main.py
├── modelos/            # Persona, Estudiante, Profesor, Asignatura, Calificacion, RegistroAcademico
├── servicios/          # GestorAcademico (reglas del negocio y estadísticas)
├── interfaz/
│   ├── ventana_principal.py   # ventana, navegación, diálogos y vistas CRUD
│   ├── vista_dashboard.py     # panel general con gráficas
│   ├── vista_asignaturas.py   # tarjetas y detalle de cada asignatura
│   ├── componentes.py         # tarjetas KPI, tarjeta de gráfica, tablas, botones, avisos
│   ├── graficas.py            # gráficas de Matplotlib (sin Tkinter, fáciles de probar)
│   └── tema.py                # colores y fuentes
├── pruebas/            # pruebas unitarias
└── docs/INFORME_TECNICO.md
```

## Datos de demostración

Al iniciar por primera vez, la aplicación carga automáticamente 10 estudiantes, 4 profesores, 5 asignaturas y registros de calificaciones ficticios para que puedas explorar los módulos. Puedes editarlos o eliminarlos desde la interfaz. Los datos se vuelven a cargar al iniciar porque no hay persistencia.

## Almacenamiento

Los datos se guardan en listas y objetos en memoria. Al cerrar la aplicación, la información se pierde. Esto es intencional para cumplir el alcance del ejercicio sin utilizar bases de datos ni archivos de persistencia.

## Conceptos POO demostrados

- **Abstracción:** `Persona` es una clase abstracta.
- **Herencia:** `Estudiante` y `Profesor` heredan de `Persona`.
- **Polimorfismo:** ambos implementan `mostrar_informacion()` de forma diferente.
- **Encapsulamiento:** `Persona` protege sus atributos y `Calificacion` valida su nota mediante una propiedad.
- **Asociación:** una asignatura puede tener un profesor responsable.
- **Agregación:** `GestorAcademico` administra objetos de estudiantes, profesores y asignaturas.
- **Composición:** `RegistroAcademico` crea y contiene sus tres objetos `Calificacion`.

## Autor

Proyecto académico EDUCONTROL.
